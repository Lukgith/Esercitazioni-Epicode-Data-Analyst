#Esercizio 6
#Scrivere una funzione che,
#data una lista di numeri,
#fornisca in output i tre numeri più grandi;
#gestire il caso in cui la lista sia più corta di tre,
#e quando uno o più dei numeri selezionati sono uguali.


def intake_interi (n) :
    print('Dammi un intero N a tuo piacere :')
    n=int(input())
    return n

def SortTopTre(l=[], m=[]) :
    l.sort()
    l.reverse()
    for i in range(0,len(l),1) :
            m.append(l[i])
    
    return(m)
    
#Dichiarazione Liste e Variabili
insiemeInteri = []
TopTre = []
n = 0 

#Richiesta del numero di interi voluti in Lista
N = int(input('Dammi un numero N che rappresenti il totale degli interi che inserirai fra poco 1 per 1:'))

#Chiamata alla funzione di Inserimento Intake da dentro Append a creare la Lista
for i in range(0,N,1) :
    insiemeInteri.append(intake_interi (n))
    
#Chiamata alla Funzione SortTop3 a generare una Lista ordinata in senso Decrescente con un numero N di elementi
SortTopTre(insiemeInteri,TopTre) 

print(TopTre)
