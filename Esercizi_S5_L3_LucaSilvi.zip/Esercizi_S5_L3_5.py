#Esercizio 5
#Scrivere una funzione che,
#data una lista di numeri,
#fornisca in output il minimo e il massimo
#(possiamo usare o meno le funzioni min() e max() nel corpo).

def intake_interi (n) :
    print('Dammi un intero N a tuo piacere :')
    n=int(input())
    return n

def max (a,b,c) :
    massimo = a
    if b > a :
        massimo = b
        if c > b and c > a:
            massimo = c
    return massimo

n = 0
a = intake_interi(n)
b = intake_interi(n)
c = intake_interi(n)

print('Il massimo tra i 3 numeri di su è:', max(a,b,c))
