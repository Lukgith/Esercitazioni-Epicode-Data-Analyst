#Esercizio 1 (S5_L3)
#Scegliere almeno 3 esercizi del giorno precedente 
#e riscriverli con un ciclo for invece che while :

#1°) #Esercizio 11 (S5_L2)
#Abbiamo una lista di codici fiscali:

lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"]

#• trovare i codici fiscali che contengono "95", metterli in una lista, e alla fine stamparla;
#• inoltre, per ognuno di essi, stampare a video i caratteri relativi al nome e ed al cognome

#con i for
codici95 = []
Nome_Cognome = []

for i in range(0, len(lista_cf), 1) :
    if '95' in lista_cf[i]:
          codici95.append(lista_cf[i])         
print(codici95)

for j in range(0, len(codici95), 1) :
        Nome_Cognome.append(codici95[j][0:6])
        print(Nome_Cognome[j][0:3]+'_'+Nome_Cognome[j][-3:])


#2°) #Esercizio 10 (S5_L2)
#Abbiamo una lista con i guadagni degli ultimi 12 mesi: 

guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50] 

#usando un costrutto while, calcolare la media dei guadagni e stamparla a video.


#con il for
somma = 0
for i in range(0, len(guadagni), 1) :
     somma += guadagni[i]
     i += 1
media = (somma)/(len(guadagni))
print(media)


#3°) #Esercizio 13 (S5_L2)
#Abbiamo una lista di stringhe di prezzi in dollari,
#che erroneamente sono stati scritti con il simbolo dell'euro:

prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]

#cambiare il simbolo dell'euro (€) in quello del dollaro ($) per ogni stringa nella lista;
#il risultato sarà memorizzato in un'altra lista.


for i in range(0,len(prezzi),1) :
    prezzo = prezzi[i]
    prezzi[i] = prezzo.replace('€','$')
    i+=1
print(prezzi)
guadagni = prezzi