#Esercizio 2
#Creiamo un dizionario che assegni ad ogni proprietario la sua auto,
#sapendo che:
#• Ada guida una Punto
#• Ben guida una Multipla
#• Charlie guida una Golf
#• Debbie guida una 107
#Stampiamo il dizionario per intero, e poi l'auto associata a Debbie.

registro_Clienti = {"Ada":"Punto", "Ben":"Multipla", "Charlie":"Golf", "Debbie":"107"}

print(registro_Clienti)

print('L\'auto associata alla Sig.ra Debbie nostra cliente è una', registro_Clienti["Debbie"])