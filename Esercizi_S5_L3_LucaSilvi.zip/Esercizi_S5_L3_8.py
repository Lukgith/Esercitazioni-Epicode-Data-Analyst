#Esercizio Scrivere una funzione che,
#data una lista di numeri,
#come output stamperà lo stesso numero di asterischi su righe diverse,
#ottenendo una semplice visualizzazione grafica

#Funzione intakeInLista prende in input una Lista vuota e restituisce la stessa colmata
def intakeInLista (l=[]) :
    N = int(input('Dammi un numero N che rappresenti il totale degli interi che inserirai fra poco 1 per 1:'))
    for i in range(0,N,1) :
        print('Dammi un intero N a tuo piacere :')
        n=int(input())
        l.append(n)
    return (0)

#Funzione mediaInLista>K prende in input la Lista e stampa per ogni elemento della Lista, un n° di *, con n°* = Lista[i]

def stampaAsterischi (L) :
    
    for i in range(0,len(L),1) :
        j = L[i]
        for k in range(0,j,1) :
            print('*', end='')
        print('\n', end='')               
    return(0)

#Dichiarazione delle variabili e Liste

l = [] 

#Chiamata alla funzione intakeInLista

intakeInLista (l)


#Chiamata alla funzione stampaAsterischi
  
stampaAsterischi (l)
