#Esercizio Scrivere una funzione che in input acquisisce una lista di numeri e un numero K;
#in output,
#dovrà restituire la media di tutti i numeri nella lista maggiori o uguali a K;
#se non ce ne dovesse essere nessuno, dovrà stampare a schermo un messaggio adeguato.



#Funzione intakeInLista prende in input una Lista vuota e restituisce la stessa colmata ed un n°intero K
def intakeInLista (l=[]) :
    J = int(input('Dammi un numero intero K :'))
    N = int(input('Dammi un numero N che rappresenti il totale degli interi che inserirai fra poco 1 per 1:'))
    for i in range(0,N,1) :
        print('Dammi un intero N a tuo piacere :')
        n=int(input())
        l.append(n)
    return (J)

#Funzione mediaInLista>K prende in input K e la Lista e con 1 ciclo for restituisce media == 0 o != 0
def mediaInListaMaggioriDiK (K,L) :
    somma = 0
    count = 0
    for i in range(0,len(L),1) :
        j = L[i]
        
        if (j < K) :
            somma += j
            count += 1 
        else :
            somma += j
        
    if (count == 5) :
        media = 0
    else :
        media = float(somma/len(L))   
    return(media)

#Dichiarazione delle variabili e Liste

l = [] 

#Chiamata alla funzione intakeInLista

K = intakeInLista (l)


#Chiamata alla funzione mediaMagg>K
  
mediaMaggUgK = mediaInListaMaggioriDiK (K,l)


#Condizionale sul valore di mediaMagg>K; se == 0 non restituisce valore per la media altrimenti si

if mediaMaggUgK == 0 :
    print('La lista non contiene numeri >= K')
else :
    print('La media degli interi in Lista è :', mediaMaggUgK)