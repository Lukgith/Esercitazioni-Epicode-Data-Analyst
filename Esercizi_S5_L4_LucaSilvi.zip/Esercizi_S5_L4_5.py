#5. Gestione di una classe Prodotto:
#Crea una classe Prodotto con attributi come nome, prezzo e quantità disponibile.
#Aggiungi metodi per calcolare il costo totale e verificare la disponibilità.

class Prodotto:
    def __init__(self,nom,prix,quantiteDisponible):
        self.nome = nom
        self.prezzo = prix
        self.quantitaDisponibile = quantiteDisponible

    def CostoTotaleGamma(self):
        if self.quantitaDisponibile == 0 :
            print('Il costo del prodotto', self.nome,'per pezzo è pari a = ', (self.prezzo),'€','\nIl costo Totale in € del prodotto',self.nome,'non è stimabile in quanto il prodotto è correntemente esaurito')
        else :
            print('Il costo Totale del prodotto',self.nome,'è pari a = ', (self.prezzo*self.quantitaDisponibile),'€')

    def Disponibilita(self):
        if self.quantitaDisponibile == 0 :
            print('Il prodotto',self.nome,'è correntemente esaurito')
        else :
            print('Il prodotto',self.nome,'c\'è ed è = ',(self.quantitaDisponibile),'pezzi')

Prodotto1 = Prodotto("Pomodoro", 3.0, 100)
Prodotto2 = Prodotto("Cassa d\'Acqua", 1.5, 0)

Prodotto1.CostoTotaleGamma()
Prodotto2.CostoTotaleGamma()
Prodotto1.Disponibilita()
Prodotto2.Disponibilita()