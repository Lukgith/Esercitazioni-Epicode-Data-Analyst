#1. Creazione di una classe Persona: 
#Crea una classe Persona con attributi come nome, cognome e età.
#Inserisci un metodo per stampare le informazioni della persona. 



class Persona:
    def __init__(self, nom, prenom, age):
        self.nome = nom 
        self.cognome = prenom 
        self.eta = age

    def StampaInfo(self):
        print(self.nome,self.cognome,self.eta)

agender_uno = Persona("Marta", "Stannis", "scienze politiche")
agender_due = Persona("Py", "Mike", "programmazione")

#Persona.StampaInfo(agender_uno)
#Persona.StampaInfo(agender_due)

agender_uno.StampaInfo()
agender_due.StampaInfo()



#3. Creazione di una classe Cerchio:
#Definisci una classe Cerchio con un attributo raggio e metodi per calcolare l'area e la circonferenza.