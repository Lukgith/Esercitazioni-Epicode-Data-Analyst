#2. Gestione di una classe Libro:
#Creare una classe Libro con attributi come titolo, autore e anno di pubblicazione.
#Aggiungi un metodo per verificare se il libro è recente.

from datetime import datetime

current_datetime = datetime.now()

class Libro:
    def __init__(self,titre,auteur,anneéDePublication):
        self.titolo = titre
        self.autore = auteur
        self.annoDiPubblicazione = anneéDePublication
    
    def EtaLibro (self):
        if 50 < (current_datetime.year - self.annoDiPubblicazione) <= 100 :
            print('Il libro ricercato non può essere considerato come recente = NR')
        elif  (current_datetime.year - self.annoDiPubblicazione) > 100 :
            print('Il libro ricercato può essere considerato come un classico = C')
        else :
            print('Il libro ricercato può essere considerato uno recente = R')


libro_uno = Libro("Otello", "William Shakespeare", 1603)
libro_due = Libro("Il Mondo Nuovo", "Aldous Huxley", 1932)
libro_tre = Libro("I Pilastri della Terra","Ken Follet",1989)
libro_quattro = Libro("Il Codice Da Vinci","Dan Brown",2003)


libro_uno.EtaLibro()
libro_due.EtaLibro()
libro_tre.EtaLibro()
libro_quattro.EtaLibro()

