#6. Inventa una tua classe che ti possa essere utile per future analisi dati

#Capacità Polmonari

class VolumiPolmonariStatici:
    def __init__(self,volumeCourant,volumeDeReserveInspiratoire,volumeDeReserveExpiratoire,volumeResiduel):
        self.volumeCorrente = volumeCourant
        self.volumeDiRiservaInspiratorio = volumeDeReserveInspiratoire
        self.volumeDiRiservaEspiratorio = volumeDeReserveExpiratoire
        self.volumeResiduo = volumeResiduel

    def CapacitaVitale (self):
        cV = self.volumeCorrente+self.volumeDiRiservaInspiratorio+self.volumeDiRiservaEspiratorio
        return cV
    
    def CapacitaPolmonareTotale(self) :
        cPToT = self.volumeCorrente+self.volumeDiRiservaInspiratorio+self.volumeDiRiservaEspiratorio+self.volumeResiduo
        return cPToT
    
    def CapacitaInspiratoria(self):
        cI = self.volumeCorrente+self.volumeDiRiservaInspiratorio
        return cI
    
    def CapacitaFunzionaleResidua(self):
        cFR = self.volumeDiRiservaEspiratorio+self.volumeResiduo
        return cFR
    

class VolumiPolmonariDinamici:
    def __init__(self, volumeaireforceenuneseconde, volumeCourant,volumeDeReserveInspiratoire,volumeDeReserveExpiratoire, ventilationmaximaleparminute):
        self.vafs = volumeaireforceenuneseconde
        self.volumeCorrente = volumeCourant
        self.volumeDiRiservaInspiratorio = volumeDeReserveInspiratoire
        self.volumeDiRiservaEspiratorio = volumeDeReserveExpiratoire
        self.vmm = ventilationmaximaleparminute


    def IndiceDiTiffeneau(self):
        IDT = (self.vafs*100)/(self.volumeCorrente+self.volumeDiRiservaInspiratorio+self.volumeDiRiservaEspiratorio)
        return IDT
    

    

class Pazienti:
    def __init__(self,nom,prenom,anneéDeNaissance,codefiscal,adresse):
        self.nome = nom
        self.cognome = prenom
        self.annoDiNascita = anneéDeNaissance
        self.codiceFiscale = codefiscal
        self.Indirizzo = adresse



Paziente1 = Pazienti('Giovanni','Mendichetti','1990','MDTGVN90A01M924U','Via Domiziano N°1 Roma')
Paziente2 = Pazienti('Luca','Cionco','1992','CNCLCU92T22M810E','Via Diocleziano N°20 Andria')
Paziente3 = Pazienti('Antonello','Cuorcontento','1960','CCTNLL60D03M356T','Via Sorbillo N°2 Napoli')

Kg1a = 70
Kg2a = 65
Kg3a = 75

Vc1a = 7.5*Kg1a #ml
Vc2a = 7.5*Kg2a #ml
Vc3a = 7.5*Kg3a #ml

vRI1a = 2500 #ml
vRI2a = 2500 #ml
vRI3a = 2500 #ml

vRE1a = 1350 #ml
vRE2a = 1350 #ml
vRE3a = 1350 #ml

vR1a = 1200 #ml
vR2a = 1200 #ml
vR3a = 1200 #ml

vafs1a = 3350 # mL*s
vafs2a = 3400 # mL*s
vafs3a = 3450 # mL*s


PrimoPaziente = VolumiPolmonariStatici(Vc1a,vRI1a,vRE1a,vR1a)
SecondoPaziente = VolumiPolmonariStatici(Vc2a,vRI2a,vRE2a,vR2a)
TerzoPaziente = VolumiPolmonariStatici(Vc3a,vRI3a,vRE3a,vR3a)
    

print('La Capacità Polmonare totale di',Paziente1.cognome,Paziente1.nome,'è pari a =',PrimoPaziente.CapacitaPolmonareTotale(),'Ltr')
print('La Capacità Polmonare totale di',Paziente2.cognome,Paziente2.nome,'è pari a =',SecondoPaziente.CapacitaPolmonareTotale(),'Ltr')
print('La Capacità Polmonare totale di',Paziente3.cognome,Paziente3.nome,'è pari a =',TerzoPaziente.CapacitaPolmonareTotale(),'Ltr')