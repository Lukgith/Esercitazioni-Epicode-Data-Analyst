#3. Creazione di una classe Cerchio:
#Definisci una classe Cerchio con un attributo raggio e metodi per calcolare l'area e la circonferenza.

import math

class Cerchio:
    def __init__(self,rayon):
        self.raggio = rayon
    def Area (self):
        zone = float(math.pi*(self.raggio*self.raggio))
        return zone
    def Circonferenza (self):
        circonference = float(2*math.pi*self.raggio)
        return circonference


raggio1 = Cerchio(15.0)
raggio2 = Cerchio(20.0)
raggio3 = Cerchio(25.0)

#Aree

Area1 = Cerchio.Area(raggio1)
print('L\'Area 1 è = ',Area1)
Area2 = raggio2.Area()
print('L\'Area 2 è = ',Area2)
Area3 = raggio3.Area()
print('L\'Area 3 è = ',Area3)

#Circonferenze

Circonferenza1 = raggio1.Circonferenza()
print('La Circonferenza 1 è = ',Circonferenza1)
Circonferenza2 = raggio2.Circonferenza()
print('La Circonferenza 2 è = ',Circonferenza2)
Circonferenza3 = raggio3.Circonferenza()
print('La Circonferenza 3 è = ',Circonferenza3)

