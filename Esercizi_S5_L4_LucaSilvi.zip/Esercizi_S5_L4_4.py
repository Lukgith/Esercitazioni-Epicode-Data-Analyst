# 4. Simulazione di un Conto Bancario: 
#Crea una classe ContoBancario con attributi saldo e metodo per depositare e prelevare denaro.

class ContoBancario:
    def __init__(self, equilibre):
        self.saldo = equilibre

    def Deposito (self,aggiunta):
        self.saldo += aggiunta
        return self.saldo

    def Prelievo(self,ritiro):
        self.saldo -= ritiro
        return self.saldo

#Assegnazione attuale di valore alla variabile Saldo
Saldo = ContoBancario(1000)
print('Originario',Saldo)

#Definizione dei parametri delle operazioni su conto
Aggiunta = 1000
Ritiro = 1000

#Chiamata al metodo Prelievo della classe ContoBancario e stampa di Saldo Aggiornato secondo metodo
Saldo = Saldo.Prelievo(Ritiro)
print('Decrementato',Saldo)

#Aggiornamento del valore di saldo nella classe ContoBancario tramite la variabile Saldo con riassegnazione
Saldo = ContoBancario(Saldo)

#Chiamata al metodo Deposito della classe ContoBancario e stampa di Saldo Aggiornato secondo metodo
Saldo = Saldo.Deposito(Aggiunta)
print('Incrementato',Saldo)

