#Estraiamo le prime    20      istanze della colonna AAPL delle azioni di Apple,
#e visualizziamo il grafico tramite pyplot, in modo che:

#• il grafico sia rosso --> .plot(color='r)
#• la linea sia tratteggiata ---> .plot(linestyle = 'dashed')
#• vi sia un pallino come marker ---> .plot(marker='o')
#• l'asse delle ascisse si chiami "Data" ---> .xlabels("Data")
#• l'asse delle ordinate si chiami "Valore" ---> .ylabel("Valore")
#• il titolo del grafico sia "Azioni Apple" ---> .title("Azioni Apple")
#• il markerfacecolor sia nero ---> .plot(markerfacecolor='black')
#• la linea abbia spessore uguale a 2 ---> .plot(linewidth=2)


import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt

Stockdata = pd.read_csv('stockdata.csv')

Date = Stockdata.loc[:,'Date']

AAPL = Stockdata.loc[:,'AAPL']

Top20AAPL = AAPL.head(20)

Top20Date = Date.head(20)


plt.plot(Top20Date, Top20AAPL, color='r',linestyle = 'dashed',linewidth=2, marker='o', markerfacecolor='black')
plt.xlabel("Data")
plt.ylabel("Valore")
plt.title("Azioni Apple")
plt.show()