import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

#5) N°Immigranti per Sesso nel triennio 2015-2017

Sexes = pd.read_csv("immigrants_emigrants_by_sex.csv")
imm_per_sex = Sexes.groupby("Gender")["Immigrants"].sum() #semplice bar plot verticale 
print(imm_per_sex)                                        # sarebbe stato meglio riportare il valore in barra
imm_per_sex.plot(kind= 'bar', color='green')             # data la poca differenza in valore
plt.title("Totale Immigrazione per genere")
plt.xlabel('Numero di Immigrati')
plt.ylabel("Genere")
plt.grid()
plt.show()