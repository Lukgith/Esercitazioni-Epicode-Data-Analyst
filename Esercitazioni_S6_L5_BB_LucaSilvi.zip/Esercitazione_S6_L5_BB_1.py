import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")




#1) distribuzione temporale immigrazione 

Anno = Immigration.groupby(['Year'])["Number"].sum() #con la groupby si ottiene un riordinamento
                                                     #e si somma per Anno
print(Anno)

Anno.plot( kind='bar',
          ylabel = 'N°ImmigratiToTAnnuo',
            title = 'Distribuzione Temporale Immigrazione',  #al che per ottenere la distribuzione temporale
            grid = True                                     #sul triennio plottiamo il dataframe 
               )
plt.tight_layout()
plt.show()
