import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")

#3) Quali sono i distretti che hanno ricevuto il maggior numero di immigrati?

DistrictSum = Immigration.groupby(['District Name'])["Number"].sum() #con la groupby si ottiene un riordinamento
                                                                    #e si somma per Distretto

print(DistrictSum.index)

DistrictSum = pd.DataFrame(DistrictSum)

plt.pie(data=DistrictSum, x='Number', autopct='%1.1f%%', labels = DistrictSum.index)
plt.set_title = 'Distretti divisi per numero di Immigrati ricevuti nel triennio 2015-2017'# grafico a torta
plt.show()                                                                                #manca il titolo
