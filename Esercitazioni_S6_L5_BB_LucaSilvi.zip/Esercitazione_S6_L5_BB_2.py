import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")

#2) Quali sono le nazionalità più comuni tra gli immigrati dell'anno 2015?

Anno2015 = Immigration[Immigration["Year"]==2015] #scegliamo un array costituito dai soli valori del 2015

Anno2015 = pd.DataFrame(Anno2015)

Top10Immigrati2015 = Anno2015.sort_values(by=['Number'],ascending=False)  #sort decrescente su Anno2015


Naz_TopImmigration2015 = pd.DataFrame([Top10Immigrati2015.loc[:,'Number'],Top10Immigrati2015.loc[:,'Nationality']]).T

#dataframe sulle sole colonne Number e Nationality, ovvero Numero e Nazionalità

Naz_TopImmigration2015 = Naz_TopImmigration2015.sort_values(by=['Number'],ascending=False)

print(Naz_TopImmigration2015[0:20])



fig, axes = plt.subplots(1, 2, figsize=(15, 5), sharey=True)               # questo subplot rispetto a quello dei colleghi
fig.suptitle('Subplots - Top Numero di Immigrati del 2015 per Nazionalità')# riporta nel caso un unica barra la quale 
                                                                           #rappresenta una media nel caso di stesse classi contigue su x
# Top10                                                                    # e presenta anche la dev.std, se invece la classe è solo 1 riporta il valore di solo quella
sns.barplot(data = Naz_TopImmigration2015[:10], ax=axes[0], x='Nationality', y='Number', color = 'red', width = 0.4)
axes[0].set_xlabel('Nazionalità')
axes[0].set_ylabel('Media su Nazionalità')


# Top10-20

sns.barplot(data = Naz_TopImmigration2015[10:20], ax=axes[1], x='Nationality', y='Number',color = 'grey', width = 0.4)
axes[1].set_xlabel('Nazionalità')
axes[1].set_ylabel('Media su Nazionalità')
plt.tight_layout()
plt.show()