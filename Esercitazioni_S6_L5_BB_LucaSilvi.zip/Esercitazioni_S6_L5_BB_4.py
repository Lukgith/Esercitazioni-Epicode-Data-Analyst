import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

#4) Età per Distretto nel triennio 2015-2017

Immigrants_by_Age = pd.read_csv("immigrants_emigrants_by_age.csv")

Immigration_by_Age = pd.DataFrame(Immigrants_by_Age.groupby("Age")["Immigrants"].sum().sort_index(ascending=False))

Emigration_by_Age = pd.DataFrame(Immigrants_by_Age.groupby("Age")["Emigrants"].sum().sort_index(ascending=False))

fig, axes = plt.subplots(1, 2, figsize=(15, 5), sharey=True)
fig.suptitle('Subplots - Immigrati ed Emigrati nel triennio 2015-2017 divisi per fasce da 4 anni di età')

# pclass
sns.barplot(data = Immigration_by_Age, ax=axes[0], x="Age", y="Immigrants", color = 'red')
axes[0].set_title('Immigrati')
axes[0].set_xlabel('Fasce d\'Età')
axes[0].set_ylabel('N°Totale per fascia')


# age

sns.barplot(data = Emigration_by_Age, ax=axes[1], x="Age", y="Emigrants",color = 'grey')
axes[1].set_title('Emigrati')
axes[1].set_xlabel('Fasce d\'Età')
axes[1].set_ylabel('N°Totale per fascia')
plt.tight_layout()
plt.show()                                  # nuovo subplot, ci sarebbe da mettere in verticale i nomi  
                                            # di fascia d'età che sono le classi su x