import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

#5) N°Immigranti per Sesso nel triennio 2015-2017

Sexes = pd.read_csv("immigrants_emigrants_by_sex.csv")             #creazione di un DataFrame d'importo
Immigrants_per_sex = Sexes.groupby("Gender")["Immigrants"].sum()   # np.Series ai fini del riordine e della somma
Immigrants_per_sex = pd.DataFrame(Immigrants_per_sex)              # trasformazione in DataFrame in quanto x necessita di un asarry                   
plt.pie(data= Immigrants_per_sex,
        x = 'Immigrants',
        autopct='%1.1f%%', 
        labels = Immigrants_per_sex.index,
        pctdistance=0.4, 
        labeldistance=1.2,
        colors = {'pink':'Male','skyblue':'Female'},
        textprops={'fontname':'Times New Roman','fontsize': 12},
        radius=1,
        startangle=90,                                             # grafico a torta
        counterclock=False,
        shadow=False,
        wedgeprops={'edgecolor': 'white', 'linewidth': 1})            
plt.title("Totale Immigrazione Dataset per genere", fontdict={'fontname':'Times New Roman','fontsize': 16}, color ='orangered')
plt.show()