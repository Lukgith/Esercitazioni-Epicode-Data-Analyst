import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")

#2) Quali sono le nazionalità più comuni tra gli immigrati dell'anno 2015?

Anno2015 = Immigration[Immigration["Year"]==2015] #scegliamo un array costituito dai soli valori del 2015

Anno2015 = pd.DataFrame(Anno2015)

Top10Immigrati2015 = Anno2015.sort_values(by=['Number'],ascending=False)  #sort decrescente su Anno2015


Naz_TopImmigration2015 = pd.DataFrame([Top10Immigrati2015.loc[:,'Number'],Top10Immigrati2015.loc[:,'Nationality']]).T

#dataframe sulle sole colonne Number e Nationality, ovvero Numero e Nazionalità

Naz_TopImmigration2015 = Naz_TopImmigration2015.sort_values(by=['Number'],ascending=False)

print(Naz_TopImmigration2015[0:20])

Naz_TopImmigration2015['subgroup'] = Naz_TopImmigration2015.groupby('Nationality').cumcount()+1

fig, axes = plt.subplots(1, 2, figsize=(6, 4), sharey=True)                                            # questo subplot rispetto a quello dei colleghi
fig.suptitle('Subplots - Flussi di Immigrati nel 2015 ordinati in senso decrescente per Nazionalità')  # riportava nel caso un unica barra la quale 
                                                                                                       #rappresentava una media nel caso di stesse classi contigue su x
# Top10                                                                                                # e presentava anche la dev.std, se invece la classe è solo 1 riportava il valore di solo quella
                                                                                                       # con l'utilizzo della funzione cumcount e di una colonna al dataFrame, rinominata 'Subgroup',
                                                                                                       # da plottare, chiamata in argomento 'hue', riusciamo ad evitare la precedente disposizione frutto del arg. 'estimator' = mean
ax1 = sns.barplot(data = Naz_TopImmigration2015[:10], ax=axes[0], x='Nationality', y='Number',hue='subgroup', color = 'red', width = 0.4,ec='w', linewidth=2.5)
axes[0].set_xlabel('Nazionalità')
axes[0].set_ylabel('Media su Nazionalità')
axes[0].set_title("I primi 10 Flussi ordinati per numerosità Decrescente")
ax1.tick_params(left=True, labelleft=True)
for bars_group in ax1.containers:
    ax1.bar_label(bars_group, padding=3, fontsize=4)
ax1.legend(bbox_to_anchor=(1, .5), loc='center left')




# Top10-20

ax2 = sns.barplot(data = Naz_TopImmigration2015[10:20], ax=axes[1], x='Nationality', y='Number',hue='subgroup',color = 'grey', width = 0.4, ec='w', linewidth=2.5)
axes[1].set_xlabel('Nazionalità')
axes[1].set_ylabel('Media su Nazionalità')
axes[1].set_title("I Flussi dal 10° al 20° ordinati per numerosità Decrescente")
ax2.tick_params(left=True, labelleft=True)
for bars_group in ax2.containers:
    ax2.bar_label(bars_group, padding=5, fontsize=4)
ax2.legend(bbox_to_anchor=(1, .5), loc='center left')
sns.despine()
plt.tight_layout()
plt.show()