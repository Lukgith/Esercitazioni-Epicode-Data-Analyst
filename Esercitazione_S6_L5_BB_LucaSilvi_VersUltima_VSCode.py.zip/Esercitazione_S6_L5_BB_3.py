import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")

#3) Quali sono i distretti che hanno ricevuto il maggior numero di immigrati?

DistrictSum = Immigration.groupby(['District Name'])["Number"].sum() #con la groupby si ottiene un riordinamento
                                                                    #e si somma per Distretto

DistrictSum = pd.DataFrame(DistrictSum) #da np.Series a DataFrame

tnrfont = {'fontname':'Times New Roman'}            #dict. di un font

torta = plt.pie(data=DistrictSum, 
                x='Number', 
                autopct='%1.1f%%', 
                labels = DistrictSum.index,
                textprops={'fontname':'Times New Roman'},
                radius=1,
                startangle=90,                                             # grafico a torta
                counterclock=False,
                shadow=False,
                wedgeprops={'edgecolor': 'white', 'linewidth': 1},
                pctdistance=0.85)     
plt.title('Distretti divisi per n° di Immigrati del triennio 2015-2017', color = 'g',**tnrfont, weight = 'bold')
plt.show()                                                                                
