import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")




#1) distribuzione temporale immigrazione 

Anno = Immigration.groupby(['Year'])["Number"].sum() #con la groupby si ottiene un riordinamento
                                                     #e si somma per Anno
print(Anno)

plt.style.use('fivethirtyeight')

Anno.plot( kind='bar',
           width = 0.25,
           alpha = 0.85,
           color = ['darkorange','red','gold'],  #al che per ottenere la distribuzione temporale
           grid = True                                      #sul triennio plottiamo il dataframe 
               )
csfont = {'fontname':'Comic Sans MS'}
cbfont = {'fontname':'Calibri'}
plt.ylabel('N°Immigrati_ToT_Annuo',color='limegreen',**cbfont)
plt.xlabel('Anni del Triennio',color='limegreen',**cbfont)
plt.title('Distribuzione Temporale Immigrazioni in Barcellona su 1 Triennio', color = 'g',**csfont, weight = 'bold')
plt.tight_layout()
plt.show()
