import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

Immigration = pd.read_csv("immigrants_by_nationality.csv")

#2) Quali sono le nazionalità più comuni tra gli immigrati nel triennio 2015-2017?




#2015




Anno2015 = Immigration[Immigration["Year"]==2015]            #un array costituito dai soli valori del 2015

Anno2015 = pd.DataFrame(Anno2015)                                         #da array a DataFrame pandas

Top10Immigrati2015 = Anno2015.sort_values(by=['Number'],ascending=False)  #sort decrescente su Anno2015


Naz_TopImmigration2015 = pd.DataFrame([Top10Immigrati2015.loc[:,'Number'],Top10Immigrati2015.loc[:,'Nationality']]).T

#dataframe sulle sole colonne Number e Nationality, ovvero Numero e Nazionalità

Naz_TopImmigration2015 = Naz_TopImmigration2015.sort_values(by=['Number'],ascending=False) #ordinamento decrescente secondo la colonna 'Number'

Naz_TopImmigration2015['subgroup'] = Naz_TopImmigration2015.groupby('Nationality').cumcount()+1

#colonna indice aggiunta da assegnare a hue per il plot distinto di flussi appartententi alla stessa Nazionalità
# che altrimenti sarebbero raggruppati in una sola bar, "media" dei flussi di una Stessa Nazionalità
#per il parametro 'estimator' di default su mean in seaborn.barplot()





#2016





Anno2016 = Immigration[Immigration["Year"]==2016]            #un array costituito dai soli valori del 2016

Anno2016 = pd.DataFrame(Anno2016)                                         #da array a DataFrame pandas

Top10Immigrati2016 = Anno2016.sort_values(by=['Number'],ascending=False)  #sort decrescente su Anno2016


Naz_TopImmigration2016 = pd.DataFrame([Top10Immigrati2016.loc[:,'Number'],Top10Immigrati2016.loc[:,'Nationality']]).T

#dataframe sulle sole colonne Number e Nationality, ovvero Numero e Nazionalità

Naz_TopImmigration2016 = Naz_TopImmigration2016.sort_values(by=['Number'],ascending=False) #ordinamento decrescente secondo la colonna 'Number'

Naz_TopImmigration2016['subgroup'] = Naz_TopImmigration2016.groupby('Nationality').cumcount()+1

#colonna indice aggiunta da assegnare a hue per il plot distinto di flussi appartententi alla stessa Nazionalità
# che altrimenti sarebbero raggruppati in una sola bar, "media" dei flussi di una Stessa Nazionalità
#per il parametro 'estimator' di default su mean in seaborn.barplot()





#2017




Anno2017 = Immigration[Immigration["Year"]==2017]            #un array costituito dai soli valori del 2017

Anno2017 = pd.DataFrame(Anno2017)                                         #da array a DataFrame pandas

Top10Immigrati2017 = Anno2017.sort_values(by=['Number'],ascending=False)  #sort decrescente su Anno2017


Naz_TopImmigration2017 = pd.DataFrame([Top10Immigrati2017.loc[:,'Number'],Top10Immigrati2017.loc[:,'Nationality']]).T

#dataframe sulle sole colonne Number e Nationality, ovvero Numero e Nazionalità

Naz_TopImmigration2017 = Naz_TopImmigration2017.sort_values(by=['Number'],ascending=False)  #ordinamento decrescente secondo la colonna 'Number'

Naz_TopImmigration2017['subgroup'] = Naz_TopImmigration2017.groupby('Nationality').cumcount()+1 

#colonna indice aggiunta da assegnare a hue per il plot distinto di flussi appartententi alla stessa Nazionalità
# che altrimenti sarebbero raggruppati in una sola bar, "media" dei flussi di una Stessa Nazionalità
#per il parametro 'estimator' di default su mean in seaborn.barplot()




#Barplot - Subplots




fig, axes = plt.subplots(1, 3, figsize=(6, 4), sharey=True)                                            # questo subplot rispetto a quello dei colleghi
fig.suptitle('Subplots - Flussi di Immigrati nel 2015 ordinati in senso decrescente per Nazionalità')  # riportava nel caso un unica barra la quale 
                                                                                                       #rappresentava una media nel caso di stesse classi contigue su x
# 2015                                                                                                # e presentava anche la dev.std, se invece la classe è solo 1 riportava il valore di solo quella
                                                                                                       # con l'utilizzo della funzione cumcount e di una colonna al dataFrame, rinominata 'Subgroup',
                                                                                                       # da plottare, chiamata in argomento 'hue', riusciamo ad evitare la precedente disposizione frutto del arg. 'estimator' = mean
ax1 = sns.barplot(data = Naz_TopImmigration2015[:10], ax=axes[0], x='Nationality', y='Number',hue='subgroup', color = 'red', width = 0.4,ec='w', linewidth=2.5)
axes[0].set_xlabel('Nazionalità')
axes[0].set_ylabel('Numerosità per Flusso')
axes[0].set_title("I primi > 10 Flussi del 2015")
ax1.tick_params(left=True, labelleft=True)
for bars_group in ax1.containers:
    ax1.bar_label(bars_group, padding=3, fontsize=4)
ax1.legend(bbox_to_anchor=(1, .5), loc='center left')




# 2016

ax2 = sns.barplot(data = Naz_TopImmigration2016[:10], ax=axes[1], x='Nationality', y='Number',hue='subgroup',color = 'grey', width = 0.4, ec='w', linewidth=2.5)
axes[1].set_xlabel('Nazionalità')
axes[1].set_ylabel('Numerosità per Flusso')
axes[1].set_title("I primi > 10 Flussi del 2016")
ax2.tick_params(left=True, labelleft=True)
for bars_group in ax2.containers:
    ax2.bar_label(bars_group, padding=5, fontsize=4)
ax2.legend(bbox_to_anchor=(1, .5), loc='center left')



#2017

ax3 = sns.barplot(data = Naz_TopImmigration2017[:10], ax=axes[2], x='Nationality', y='Number',hue='subgroup',color = 'skyblue', width = 0.4, ec='w', linewidth=2.5)
axes[2].set_xlabel('Nazionalità')
axes[2].set_ylabel('Numerosità per Flusso')
axes[2].set_title("I primi > 10 Flussi del 2017")
ax3.tick_params(left=True, labelleft=True)
for bars_group in ax3.containers:
    ax3.bar_label(bars_group, padding=5, fontsize=4)
ax3.legend(bbox_to_anchor=(1, .5), loc='center left')


sns.despine()
plt.tight_layout()
plt.show()