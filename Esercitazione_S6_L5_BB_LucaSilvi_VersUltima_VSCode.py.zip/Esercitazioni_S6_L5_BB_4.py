import matplotlib.pyplot as plt 
import pandas as pd
import numpy as np 
import seaborn as sns 

#4) Età per Distretto nel triennio 2015-2017

Immigrants_by_Age = pd.read_csv("immigrants_emigrants_by_age.csv")

Immigration_by_Age = pd.DataFrame(Immigrants_by_Age.groupby("Age")["Immigrants"].sum().sort_index(ascending=False))

Emigration_by_Age = pd.DataFrame(Immigrants_by_Age.groupby("Age")["Emigrants"].sum().sort_index(ascending=False))

fig, axes = plt.subplots(1, 2, figsize=(15, 5), sharey=True)
fig.suptitle('Subplots - Immigrati ed Emigrati nel triennio 2015-2017 divisi per fasce da 4 anni di età', weight = 'bold', color = 'grey', fontsize = 16)



cbfont = {'fontname':'Calibri'} #dict. di un font



# pclass
ax1=sns.barplot(data = Immigration_by_Age, ax=axes[0], x="Age", y="Immigrants", color = 'red')
axes[0].set_title('Immigrati', color = 'g', weight = 'bold')
axes[0].set_xlabel('Fasce d\'Età', color = 'orangered',**cbfont)
axes[0].set_ylabel('N°Totale per fascia', color = 'orangered',**cbfont)
for item in ax1.get_xticklabels():                       #ruota tutte le etichette delle classi in ascisse
    item.set_rotation(45)                                        # di 45°



# age

ax2=sns.barplot(data = Emigration_by_Age, ax=axes[1], x="Age", y="Emigrants",color = 'skyblue')
axes[1].set_title('Emigrati', color = 'g', weight = 'bold')
axes[1].set_xlabel('Fasce d\'Età', color = 'orangered',**cbfont)
axes[1].set_ylabel('N°Totale per fascia', color = 'orangered',**cbfont)
for item in ax2.get_xticklabels():                       #ruota tutte le etichette delle classi in ascisse
    item.set_rotation(45)                                        # di 45°
plt.tight_layout()
plt.show()                                  