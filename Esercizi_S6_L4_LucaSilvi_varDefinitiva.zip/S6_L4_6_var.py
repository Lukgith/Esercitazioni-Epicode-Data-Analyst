from altair import InlineData, InlineDataset
import matplotlib
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns 
titanic = sns.load_dataset('titanic')

print(titanic)

#Visualizzare un grafico con il numero di passeggeri di ogni classe di imbarco

PasstoClass = pd.DataFrame(data= titanic, columns = {'pclass' : 'x'})

PassXClassp = PasstoClass.value_counts()

PassXClass = pd.DataFrame(PassXClassp)

PassXClass.columns = ["NPassXClass"]

PassXClass.index = ["3rd","1st","2nd"]



plt.style.use('fivethirtyeight')

PassXClass.plot(kind='bar',
                xlabel = 'pclass',
                color = 'darkorange',
                title = 'Barplot - N° of Passengers in each Class')
plt.tight_layout()
plt.show()

#Fare la stessa cosa per la colonna alive

PasstoStatus = pd.DataFrame(data= titanic, columns = {'alive' : 'x'})

PassXStatusp = PasstoStatus.value_counts()

PassXStatus = pd.DataFrame(PassXStatusp)

PassXStatus = PassXStatus.T   #Si differenzia il colore grazie alla T, in quanto color in plot prende solo columns

PassXStatus.index = [""]#NPassXStatus

PassXStatus.columns = ["Dead","Alive"]


PassXStatus.plot(kind = 'bar',xlabel = 'Status',
                color= {'Dead':'black','Alive':'white'},     #una soluzione per colorare, che rende però le bars affiancate senza spazi
                title = 'Barplot - Current Status of Passengers')

plt.tight_layout()
plt.show()


#Qual era la distribuzione delle tariffe (fare)?
#Da distribuzioni normali di 2 variabili pressochè indipendenti, o perlomeno con buona approssimazione
#la loro distribuzione congiunta si presenta come una normale, senza considerare che la distribuzione
#B si risolve nella normale per un numeri n rappresentativi del campione grandi



#Riusciamo a vedere la distribuzione delle età dei passeggeri rispetto alla classe di imbarco?


AgetoClass = pd.DataFrame(data= titanic, columns = {'pclass' : 'x', 'age':'y'})

#AgeXClassp = AgetoClass.value_counts()

AgeXClass = pd.DataFrame(AgetoClass)

#PassXClass.columns = ["NPassXClass"]

#AgeXClass.index = ["3rd","1st","2nd"]



plt.style.use('fivethirtyeight')

AgeXClass.plot(kind='bar',
                xlabel = 'ID',
                ylabel = 'Discriminant',
                color = ['darkblue', 'orange'],
                title = 'BarPlot - Age of Passengers with each their own pClass')
plt.tight_layout()
plt.show()

#Possiamo anche vederla, il problema è che non riusciamo però a distinguere nell'insieme 
# con il Barplot, i dati associati nel grafico per il grande numero di elementi del dataset
# e la presenza di 2 variabili contemporaneamente
#inoltre fortunatamente le variabili sono valori di tipo numerico altrimenti, nel caso di 
#anche una variabile di tipo str() con un unico Barplot sarebbe stato impossibile

#Possiamo provare attraverso la creazione di 2 subplots di tipo Barplot

fig, axes = plt.subplots(1, 2, figsize=(15, 5), sharey=True)
fig.suptitle('Subplots - Age of Passengers for boarding Class')

# pclass
sns.barplot(ax=axes[0], x=AgeXClass.loc[:,'pclass'].index, y=AgeXClass.loc[:,'pclass'].values, color = 'red')
axes[0].set_title(AgeXClass.loc[:,'pclass'].name)
axes[0].set_xlabel('ID')
axes[0].set_ylabel('Discrminant')


# age

sns.barplot(ax=axes[1], x=AgeXClass.loc[:,'age'].index, y=AgeXClass.loc[:,'age'].values,color = 'grey')
axes[1].set_title(AgeXClass.loc[:,'age'].name)
axes[1].set_xlabel('ID')
#axes[1].set_ylabel('Age')
plt.tight_layout()
plt.show()


#ma come osserviamo dato il grande numero di passeggeri e la presenza di dati mancanti per età 
#nel dataset, non riusciamo ad avere riscontri che siano immediati e chiari con un prima osservazione

# oppure possiamo provare anche con un lmplot

sns.lmplot(data=titanic,
           x="pclass",
           y="age",
           scatter_kws = {'color': 'darkgrey'},
           line_kws = {'color': 'red'}).set(title = 'Lmplot - Passengers Status for Fare')
plt.tight_layout()
plt.show()

#ma la visione della distribuzione di età per ciascuna pclass all'insieme rimane così irrealizzabile.
# Si potrebbero ad es. creare 3 array a partire dal DataFrame e rapprentarne ciascuna distribuzione
#affiancandoli in subplots
#l'unica cosa che emerge è la correlazione negativa dall'Lmplot tra le variabili età/tariffa


#Proviamo con un boxplot


my_pal1 = {"1": "r", "2": "skyblue", "3":"darkorange"}
sns.boxplot(data=AgeXClass,
            y="age",
            x="pclass",
            palette= my_pal1).set(title = 'Boxplot - Age of Passengers for payment class')
plt.tight_layout()
plt.show()

# e con uno swarmplot

my_pal2 = {"1": "black", "2": "grey", "3":"darkorange"}
sns.swarmplot( data=AgeXClass,
              y="age",
              x="pclass",
              palette= my_pal2).set(title = 'SwarmPlot - Age of Passengers for payment class')
plt.tight_layout()
plt.show()


#• Visualizziamo un boxplot e un lmplot rispetto alle colonne fare e survived; che cose ne deduciamo?

my_pal3 = {"0": "black","1":"green"}
sns.boxplot(data=titanic,
            y="fare",
            x="survived",
            palette= my_pal3).set(title = 'Boxplot - Passengers Status for Fare')
plt.tight_layout()
plt.show()

sns.lmplot(data=titanic,
           x="survived",
           y="fare",
           scatter_kws = {'color': 'darkgrey'},
           line_kws = {'color': 'red'}).set(title = 'Lmplot - Passengers Status for Fare')
plt.tight_layout()
plt.show()

#ne deduciamo l'evidenza di una correlazione positiva tra le due variabili tariffa e sopravvivenza
#anche se lieve, avendo perciò l'idea di poter avere una maggiore possibilità di sopravvivenza in caso
#di incidenti se acquistassimo posti venduti a tariffe maggiori.


