import matplotlib.pyplot as plt 
import numpy as np 
import pandas as pd 
import seaborn as sbn 
import streamlit as st
from io import BytesIO

#Scarichiamo il dataset elections da https://github.com/plotly/datasets/blob/master/election.csv

elezioni = pd.read_csv('election.csv')

#Utilizzando i metodi di rappresentazione grafica dei DataFrame
#Con un grafico a barre confrontiamo i voti totali presi dai tre candidati (come somma di tutti i distretti)

VotiXCandidati = pd.DataFrame(elezioni.loc[0,'Coderre':'Joly'])

VotiXCandidati.columns=["VotiToT"]

plt.style.use('ggplot')

VotiXCandidati.plot(kind='bar',
                    title = 'N° Total de Voix pour chaque Candidat',
                    grid = True
                    )

plt.tight_layout()
plt.show()

#• Con un grafico a barre confrontiamo il numero di votanti per ogni distretto

VotiXDistrettoI = pd.DataFrame(elezioni.iloc[0:58,0:4])

VotiXDistretto = VotiXDistrettoI.set_index('district')

VotiXDistrettoTSum = VotiXDistretto.T.sum()

VotiXDistrettoTSum.plot(kind='bar')


plt.tight_layout()
plt.show()

#Visualizzare un grafico a barre comparativo
#dove si confrontano i voti presi nei primi 4 distretti, per ogni candidato:

# - Visualizzarlo sia in formato appaiato

Primi4DistrNVotiXCandidate = VotiXDistretto.head(4)

Primi4DistrNVotiXCandidate.plot(kind='bar')

plt.tight_layout()

plt.show()

# - che impilato (stacked) 
# Il valore predefinito del parametro figsize è [6.4, 4.8]

Primi4DistrNVotiXCandidate = VotiXDistretto.head(4)

Primi4DistrNVotiXCandidate.plot(kind='bar', stacked = True)

plt.tight_layout()

plt.show()

# e salvare entrambi i grafici su disco in alta risoluzione

#plt.savefig("Primi4DistrNVotiXCandidate_Bar_hi_res.png", dpi=600)
#plt.savefig("Primi4DistrNVotiXCandidate_StackedBar_hi_res.png", dpi=600)


