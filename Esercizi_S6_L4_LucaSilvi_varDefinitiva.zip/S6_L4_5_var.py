import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns 
titanic = sns.load_dataset('titanic')

print(titanic)

etichette = titanic.columns

#quanti ponti c'erano sulla nave?

NDecksReg = titanic.loc[1:,'deck'].count() #valori Nan se ce ne fossero sarebbero ignorati di default

print(NDecksReg)

#Ci sono dati Mancanti? Dove? Quanti?

NNanForLabel = titanic.isna().sum()

print(NNanForLabel)

#Che logica potremmo usare per gestirli?

#1)
#Potremmo innanzitutto eliminare dal dataset le righe contenenti i Nan appartenenti alle colonne
#le quali ne contengono un numero abbastanza piccolo da essere trascurabile ovvero una frazione 
#dell'ordine di 10 alla -3 sul Totale massimo, dalle colonne con n°Nan < 10 ancor, meglio < 5
#perciò eliminando le righe dei 4 Nan nelle colonne  embarked ed embarked_town

#2)
#Per quanto riguarda i Nan dalle colonne età e ponte, in numero significativo sul Totale
#potremmo sostituire i Nan sia per la classe età che ponte con dei valori generati casualmente
#distribuiti su una normale avente valori di media e deviazione std pari a quelli ottenuti dalla
#distribuzione di colonna, se non ha relazioni significative con altre colonne del dataset
#Oppure per la colonna ponti, sempre se non ha relazioni significative con altre colonne del dataset
#quale es potrebbe essere pclass, potremmo immaginare allora  un altra categoria di ponte 
#es. H e sostituire tutti i Nan con il valore stringa H 


#Tramite seaborn visualizziamo un lmplot sulle colonne age e fare;
#che cosa stiamo guardando?

sns.color_palette("rocket", as_cmap=True)
sns.lmplot(data=titanic, x="age", y="fare", scatter_kws = {'color': 'darkgrey'}, line_kws = {'color': 'red'})
plt.show()

#stiamo guardando un lmplot 
#Ovvero 1 grafico di dispersione con linee di regressione sovrapposte.
#L'lmplot() combina il modello di regressione lineare (regplot()) e lo scatterplot(). 
#Grafico di dispersione, Scatterplot()
#Se i dati non sono correlati tra loro, questo tipo di grafico è il migliore.
#Quando si hanno a disposizione informazioni semplici,
#il grafico di dispersione è in grado di comunicare con efficacia ogni punto di dati.
#Linear regression, regplot()
#Questo tipo di grafico ci consente di visualizzare la correlazione tra le 2 variabili
#poichè la covarianza è uguale al coefficiente angolare della e il coefficiente r di regressione
#è legato direttamente alla covarianza si ha:
#1) per coefficiente angolare b > 0 r > 0 = correlazione +
#2) per coefficiente b = 0 r = 0 correlazione nulla ovvero variabili indipendenti
#3) per coefficiente b < 0 r < 0 correlazione -
#Nel presente lmplot emerge quindi una correlazione lieve ma +




