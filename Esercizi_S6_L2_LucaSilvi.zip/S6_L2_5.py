#Esercizio 5
#Abbiamo la seguente matrice:

import numpy as np

mat = [[1,1,1,1], [5,1,1,1], [20,-4,0,42]]


#Creiamo un ndarray con gli stessi valori.
#Ci sono due modalità:
#1) inizializzare un array e poi inserire i valori nelle posizioni adatte;

Array1 = []
#for i in mat:
for x in mat:
    Array1 = np.append(mat,x)
print(Array1)

#2) oppure creare una lista di liste e poi effettuare un casting


Array2 = np.array(mat)
print(Array2)