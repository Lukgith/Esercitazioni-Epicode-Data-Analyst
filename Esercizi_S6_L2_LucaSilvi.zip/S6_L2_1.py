#Abbiamo una lista di liste: 

mat = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14]] 

#Che tipo di struttura dati o matematica potrebbe rappresentare? 

#MATRICE 3X5 (3 righe, 5 colonne)

#Notare che tutte le liste "interne" sono della stessa dimensione

#Come facciamo per accedere ad un elemento in particolare?

#es vogliamo il 4° elemento della seconda riga di matrice, che è 8:

print(mat[1][3])

# e difatti restituisce 8, ovvero l'indicizzazione è corretta