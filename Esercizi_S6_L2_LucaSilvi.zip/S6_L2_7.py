# Elencare i primi n numeri primi, chiedendo n all'utente e implementando l'algoritmo del "Crivello di Eratostene"

#Algoritmo Crivello di Eratostene:  a = p*r , con r<=p

import numpy as np

n = int(input('Dai un numero intero n a piacere come massimo di una lista crescente di interi con passo 1:'))
i = 1
primi = []

while i < n:                         # un indice i corre su tutti i numeri interi fino ad n 
    count = 0
    for x in range(1, i + 1):        # un indice x corre su tutti gli interi fino ad i 
        if i % x == 0:               # x parte da uno così da avere il dividendo sempre > 0
            count += 1               # nel momento in cui ci si trova una divisione su 1 o su lo stesso o su multipli count aumenta
    if count <= 2:                   # poichè un numero si dice primo se count è al + == 2 si impone la condizione di riconoscimento
        primi.append(i)              # e lo si inserisce in lista
    i += 1                           # finito il ciclo for per un certo i si aumenta i di 1 per il prossimo ciclo for

primi = np.array(primi)

print(primi)


