#Esercizio 3
#Abbiamo il seguente array NumPy:

import numpy as np

linear_data = np.array([x+1 for x in range(27)])

#Lo ridimensioniamo mediante il metodo .reshape():

reshaped_data = linear_data.reshape((3, 3, 3)) #gli argomenti sono in ord. n°matrici, n°righe, n°colonne

#Quante dimensioni ha il nuovo array? Come facciamo per accedere ai singoli elementi?

#Il nuovo array ha 3 dimensioni, può essere anche rappresentato come matrice 3D o tensore
#nel caso Tensore Levi-Civita

#Mettiamo di voler accedere all'elemento 3 della seconda riga della terza matrice, dovrà essere 24:

print(reshaped_data[2][1][2])

#ed è così