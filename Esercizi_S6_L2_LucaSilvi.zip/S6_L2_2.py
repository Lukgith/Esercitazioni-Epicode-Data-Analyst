#Esercizio 2
#Trasformiamo la lista dell'esercizio precedente

mat = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14]] 

#in un array NumPy: 
#mat = np.array(mat)

#Prima si fa pip install
#poi si importa numpy 

import numpy as np
npmat = np.array(mat)

print(npmat) #stampa la matrice a guisa di numpy

#Come facciamo per accedere ai singoli elementi? es il 4 della seconda riga di nuovo

print(npmat[1][3]) #perciò sempre come per le liste