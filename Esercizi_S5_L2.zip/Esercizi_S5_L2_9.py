#Esercizio 9 
#Calcolare (ma non stampare) le prime N potenze di K;
#ognuna di esse andrà memorizzata in coda a una lista.
#Alla fine, stampare la lista risultante.
#Proviamo con diversi valori di K, oppure facciamola inserire all'utente.

lista = []        
K = int(input('Dai un intero K tra 1 e 5:'))
N = int(input('Dai un intero N tra 1 e 10:'))
for i in range(1, N, 1):
     potenza = K ** i
     lista.append(potenza)
print(lista)