#Esercizio 1
#Abbiamo la stringa: nome_scuola = "Epicode" 
#Stampare ogni carattere della stringa, uno su ogni riga, utilizzando un costrutto while.

from cgi import print_arguments


nome_scuola = "Epicode"
i = 0
print('\n')
while (i < len(nome_scuola)) : 
    print(nome_scuola[i])
    i += 1
print('\n')



