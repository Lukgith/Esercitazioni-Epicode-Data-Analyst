#Esercizio 12 Abbiamo tre liste della stessa lunghezza,
#dove ogni elemento nella medesima posizione si riferisce ai dati dello stesso studente: 

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend", "Frontend", "Cybersecurity"] 
edizioni = [1, 2, 3, 2, 2, 1, 3, 3] 

#• Stampare a video tutti e soli gli studenti che frequentano una prima edizione;
#non tutti i dati potrebbero essere necessari.
#Riuscite a vedere una similarità con la logica che si usa SQL e le tabelle relazionali?

for i in range(0, len(edizioni), 1) :
    if edizioni[i] == 1 :
        print(studenti[i])
