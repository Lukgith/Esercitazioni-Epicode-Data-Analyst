#Esercizio Abbiamo una lista di studenti:

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry", "Isabelle", "John"]

#vogliamo dividere gli studenti in due squadre per un campionato di Uno nel seguente modo:
#selezioneremo i nomi in posizione pari per un squadra, e i nomi in posizione dispari per l'altra.
#Creiamo due liste per ogni squadra, e alla fine visualizziamole

squadraPari = []
squadraDispari = []
i=0
while i < len(studenti) :
    if (i % 2) == 0 :
        squadraDispari.append(studenti[i])
    else :
        squadraPari.append(studenti[i])
    i+=1
print('SquadraPari = ', squadraPari)
print('SquadraDispari = ', squadraDispari)
