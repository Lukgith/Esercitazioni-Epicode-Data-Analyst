#Esercizio 4
#Calcolare e stampare tutte le prime N potenze di 2 utilizzando un ciclo while,
#domandando all'utente di inserire N.


N = input('Inserisci un intero tra 0 e 10 :')
numero = 0
while numero <= int(N) :
        print('2^',numero,'=',2**numero)
        numero += 1