#Esercizio 2
#Stampare a video tutti i numeri da 0 a 20 utilizzando il costrutto while.

numero = 0
while numero <= 20 :
    print(numero)
    numero += 1