#Esercizio Abbiamo una lista di stringhe di prezzi in dollari,
#che erroneamente sono stati scritti con il simbolo dell'euro:

prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]

#cambiare il simbolo dell'euro (€) in quello del dollaro ($) per ogni stringa nella lista;
#il risultato sarà memorizzato in un'altra lista.

i=0
while i < len(prezzi) :
    prezzo = prezzi[i]
    prezzi[i] = prezzo.replace('€','$')
    i+=1
print(prezzi)
guadagni = prezzi