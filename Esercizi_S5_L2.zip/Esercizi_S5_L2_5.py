#Esercizio 5 Calcolare e stampare tutte le potenze di 2 minori di 25000.

numero = 0
while (2**numero) <= 25000 :
    print('2^',numero,'=',2**numero)
    numero += 1
