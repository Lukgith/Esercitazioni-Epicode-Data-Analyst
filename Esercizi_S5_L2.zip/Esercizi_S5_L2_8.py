#Esercizio 8
#Memorizza e stampa tutti i divisori di un numero dato in input.

 
numero = int(input('Dai un numero intero qualsiasi :'))
for i in range(1, 10, 1):
     if (numero % i) == 0 :
          print('Un suo divisore è =',i)