#Esercizio 10
#Abbiamo una lista con i guadagni degli ultimi 12 mesi: 

guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50] 

#usando un costrutto while, calcolare la media dei guadagni e stamparla a video.

i = 0
somma = 0
while i<len(guadagni) :
     somma += guadagni[i]
     i += 1
media = (somma)/(len(guadagni))
print(media)