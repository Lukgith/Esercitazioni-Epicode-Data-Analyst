#Esercizio 11
#Abbiamo una lista di codici fiscali:
 
lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"]
#i=0
#l=0
#print(lista_cf[0][0])
#print(len(lista_cf[0]))
#• trovare i codici fiscali che contengono "95", metterli in una lista, e alla fine stamparla;
#• inoltre, per ognuno di essi, stampare a video i caratteri relativi al nome e ed al cognome
    
#con i for
#codici95 = []
#codici95.append(lista_cf[0])
#NomeCognome = []
#i = 0
#for i in range(1,len(lista_cf)+1,1)  :
     #for k in range (1, len(lista_cf[i-1]), 1) :
         #if ((lista_cf[i-1][k-1] == 9) and (lista_cf[i-1][k] == 5)) :
          #codici95.append(lista_cf[i-1])

#print(lista_cf[i-1][k-1],lista_cf[i-1][k])  
#print(codici95)
#for j in range(1,len(codici95),1) :
        #NomeCognome.append(codici95[j-1][0:7])
#print(NomeCognome)


#con i while
#codici95 = []
#NomeCognome = []
#i = 1
#k = 1
#while i < len(lista_cf) :
     #while k < len(lista_cf[i-1]) : 
         #if ((lista_cf[i-1][k-1] == 9) and (lista_cf[i-1][k] == 5)) :
          #codici95.append(lista_cf[i-1])
          #k+=1  
     #i += 1
     
      
#print(codici95)
#j = 1
#while j < len(codici95) :
#        NomeCognome.append(codici95[j-1][0:7])
#        j+=1
#print(NomeCognome)


#con i while
codici95 = []
Nome_Cognome = []
i = 0
while i < len(lista_cf) :
    if '95' in lista_cf[i]:
          codici95.append(lista_cf[i])         
    i += 1
print(codici95)

j = 0
while j < len(codici95) :
        Nome_Cognome.append(codici95[j][0:6])
        print(Nome_Cognome[j][0:3]+'_'+Nome_Cognome[j][-3:])
        j+=1
