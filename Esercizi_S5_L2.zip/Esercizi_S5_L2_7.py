#Esercizio 7 Esercizio Scriviamo un programma che chiede
#in input all'utente una stringa e visualizza i primi 3 caratteri,
#seguiti da 3 punti di sospensione e quindi gli ultimi 3 caratteri
#(Stavolta facciamo attenzione a tutti i casi particolari,
#ovvero implementare soluzioni ad hoc per stringhe di lunghezza inferiore a 6 caratteri)


strumento = input('\nDammi una stringa di un numero qualsiasi di caratteri:')
if len(strumento) >= 6 :
    print(strumento[0:3]+"..."+strumento[-3:])
else : 
     slice = int(len(strumento)/2)
     print(strumento[0:slice]+'...'+strumento[-slice:])
