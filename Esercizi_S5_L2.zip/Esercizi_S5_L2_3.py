#Esercizio 3
#Calcolare e stampare tutte le prime 10 potenze di 2 (e.g., 2⁰, 2¹, 2², …) utilizzando un ciclo while.

numero = 0
while numero <= 10 :
    print('2^',numero,'=',2**numero)
    numero += 1