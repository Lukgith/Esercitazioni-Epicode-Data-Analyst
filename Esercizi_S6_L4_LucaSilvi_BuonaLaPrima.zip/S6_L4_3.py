#Esercizio 3/3
#• Utilizzando i metodi di rappresentazione grafica dei DataFrame,
#visualizziamo l'andamento di tutte le azioni sullo stesso grafico

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt

Stockdata = pd.read_csv('stockdata.csv')

plt.plot(Stockdata.loc[:, 'MSFT':'GSPC'], linewidth= 0.5)
plt.title('Andamento delle Azioni delle Aziende nel tempo secondo indice ins', color = 'g')
plt.xlabel('Indice', color = 'r')
plt.ylabel('Valore dell\'Azione', color = 'r')


#• Tramite pyplot, spostiamo la legenda in basso a destra
plt.legend(Stockdata.columns[0:5], loc='lower right', bbox_to_anchor=(0.98, 0.2),borderpad = 2)
plt.show()