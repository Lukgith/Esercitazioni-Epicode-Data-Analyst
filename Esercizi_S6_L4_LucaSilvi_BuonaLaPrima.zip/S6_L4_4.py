#Esercizio Scarichiamo il dataset elections da
#https://github.com/plotly/datasets/blob/master/election.csv:



import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt

Elezioni = pd.read_csv('election.csv')

colnames = Elezioni.columns


#• Con un grafico a barre confrontiamo i voti totali presi dai tre candidati
#(come somma di tutti i distretti)

VotToTBergeron = Elezioni.loc[:,'Bergeron'].sum()
VotToTCoderre = Elezioni.loc[:,'Coderre'].sum()
VotToTJoly = Elezioni.loc[:,'Joly'].sum()

# oppure così: df = pd.DataFrame(Elezioni, columns=["DatA", "CybS", "FroE", "BacE"])) --> ma stesso risultato con + op.s

BarsToTCandidate = []

BarsToTCandidate = np.append(VotToTBergeron, BarsToTCandidate)
BarsToTCandidate = np.append(VotToTCoderre,BarsToTCandidate)
BarsToTCandidate = np.append(VotToTJoly,BarsToTCandidate)

BarsToTCandidate = pd.DataFrame(BarsToTCandidate)


BarsToTCandidate.plot(kind="bar", xlabel = ['Coderre 0', 'Bergeron 1', 'Joly 2'])
plt.title('Voti Totali per Candidato', color='g')
plt.ylabel('N°Tot di Voti', color = 'black')

plt.show()


# utilizzare + pandas (riscrivere il codice utilizzando solo comandi pd)






#• Con un grafico a barre confrontiamo il numero di votanti per ogni distretto


sommaPerDistretto = Elezioni.loc[:,'Coderre'] + Elezioni.loc[:,'Bergeron'] + Elezioni.loc[:,'Joly']

sommaPerDistretto.plot(kind="bar")

plt.show()



#• Visualizzare un grafico a barre comparativo
#dove si confrontano i voti presi nei primi 4 distretti per ogni candidato •
#Visualizzarlo sia in formato appaiato che impilato (stacked)
#e salvare entrambi i grafici su disco in alta risoluzione


top4Distr = Elezioni.loc[:,'district':'Joly'].head(4)

top4Distr.plot(kind='bar')
plt.savefig("top4Distr_Bar_hi_res.png", dpi=600)

plt.show()

top4Distr.plot(kind='bar',stacked=True)
plt.savefig("top4Distr_StackedBar_hi_res.png", dpi=600)

plt.show()