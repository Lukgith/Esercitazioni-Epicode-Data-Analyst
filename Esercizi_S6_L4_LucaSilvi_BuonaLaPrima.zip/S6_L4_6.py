
#• Visualizziamo un boxplot e un lmplot rispetto alle colonne fare e survived; che cose ne deduciamo?

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns 
titanic = sns.load_dataset('titanic')

print(titanic)

#Visualizzare un grafico con il numero di passeggeri di ogni classe di imbarco

x = [i for i in range(0,891,1)]
y = [i for i in titanic.loc[:,'pclass']]

df = pd.DataFrame({"pclass": y, "indici": x})

sns.lmplot( data=df, y="indici", x="pclass")

plt.show()



#• Fare la stessa cosa per la colonna alive

indici = [i for i in range(0,891,1)]


count = 0

Vitalita=np.empty(len(titanic), dtype = int)
for i in titanic.loc[:,'alive']:
    if i == 'yes':
        Vitalita[count] = 1
        count += 1
    elif i == 'no':
        Vitalita[count] = 0
        count += 1



daf = pd.DataFrame({"Vitalita": Vitalita, "indici": indici})

sns.lmplot( data=daf, y="indici", x="Vitalita")

plt.show()



#• Qual era la distribuzione delle tariffe (fare)?

# La distribuzione delle tariffe era una normale,
# le precedenti sono distribuzioni su 2o+ valori riconducibili alla B(x)




#• Riusciamo a vedere la distribuzione delle età dei passeggeri rispetto alla classe di imbarco?

age = [i for i in titanic.loc[:,'age']]
pclass = [i for i in titanic.loc[:,'pclass']]

dfr = pd.DataFrame({"pclass": pclass, "età": age})

sns.lmplot( data=dfr, y="età", x="pclass")

plt.show()


# no, come per i precedenti in quanto si tratta di discriminazione posizionale e non cumulativa

#Proviamo con un boxplot e con uno swarmplot

sns.boxplot( data=dfr, y="età", x="pclass")

plt.show()

sns.swarmplot( data=dfr, y="età", x="pclass")

plt.show()


#migliorare la qualità dei grafici