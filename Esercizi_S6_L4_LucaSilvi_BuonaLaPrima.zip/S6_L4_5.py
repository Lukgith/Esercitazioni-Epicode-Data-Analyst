import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns 
titanic = sns.load_dataset('titanic')

print(titanic)

etichette = titanic.columns

print(etichette)

#quanti ponti c'erano sulla nave?

NToTPonti = 0

lettereAlf = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

for i in titanic.loc[:,'deck']:
    for j in lettereAlf:
        if i == j:
            NToTPonti +=1 
        else :
            NToTPonti = NToTPonti #arrivano fino alla G

print(NToTPonti) #203 ponti ToT


# Si ci sono dati mancanti in quanto Nan

NNan = 891 -203

print(NNan) # 688 Nan
# potremmo tutti inserirli in alloggio all'interno di un unico ponte, ad esempio H preso come più capiente.

sns.lmplot(data=titanic, x="age", y="fare")
plt.show()

#Stiamo guardando tariffe in base all'età


# utilizzare meglio pandas e seaborn(riscrivere il codice utilizzando solo comandi pd e sns)