#Esercizio 1/3 
#Scarichiamo il dataset stockdata da 
url = "https://github.com/plotly/datasets/blob/master/stockdata.csv"

#• Estraiamo i dati della colonna MSFT relative all'andamento delle azioni di Microsoft,
#e visualizziamolo mediante pyplot

import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt

Stockdata = pd.read_csv('stockdata.csv')

MSFT = Stockdata.loc[:,'MSFT']

# plot 1

plt.plot(MSFT, color = 'orange')
plt.title('Distribuzione temporale del MSFT StockValues', color = 'g')
plt.xlabel('Index', color = 'r')
plt.ylabel('Microsoft Corp. Stock Value', color = 'r')
plt.grid()



#• Estraiamo le prime 5 righe della colonna MSFT e della colonna date,
#e usiamoli come ascisse e ordinate su un grafico mediante pyplot

Date = Stockdata.loc[:,'Date']
print(Date)

top5MSFT = MSFT.head(5)
top5Date = Date.head(5)

# plot 2
fig, ax = plt.subplots()

ax.plot( top5Date, top5MSFT, linewidth=2.0, color = 'orange', marker='o', markerfacecolor = 'g')

plt.title('Primi 5 Valori di Stock per MSFT percepiti con Data', color = 'g')
plt.xlabel('Data', color = 'r')
plt.ylabel('Valore di Stock', color = 'r')
plt.grid()




#• Facciamo lo stesso per le ultime 5 righe del dataset

Last5MSFT = MSFT.tail(5)
Last5Date = Date.tail(5)


# plot 3
fig, ax = plt.subplots()

ax.plot( Last5Date, Last5MSFT, linewidth=2.0, color = 'orange', marker='o', markerfacecolor = 'g')

plt.title('Last 5 Valori di Stock per MSFT percepiti con Data', color = 'g')
plt.xlabel('Data', color = 'r')
plt.ylabel('Valore di Stock', color = 'r')
plt.grid()

plt.show()