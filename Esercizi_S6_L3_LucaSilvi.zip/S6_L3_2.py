import numpy as np 
import pandas as pd

iris = pd.read_csv("iris.DATA")

#print(iris.head(5)) #prime 5 righe
print(iris.head(1)) #Nomi di colonna

#COLNAMES = pd.read_csv("iris.NAMES", )  # per importare direttamente i colnames si potrebbe creare un parser per leggere le righe da files di tipo NAMES
COLNAMES = ['sepal length in cm', 'sepal width in cm', 'petal length in cm', 'petal width in cm', 'class']
print(COLNAMES)
iris = pd.read_csv("iris.DATA", names = COLNAMES , header=None)

#print(iris.head(5)) #prime 5 righe
print(iris.tail(10)) #ultime 10 righe
print(iris.describe()) #riepilogo descrittori