import numpy as np 
import pandas as pd 

vini = pd.read_csv("wine.csv", usecols = range(0,12))

print(vini)
#media = np.mean() 
#mediana = np.median() 
#dev_std = np.std()

arrayDimVini = vini.shape

print(arrayDimVini) 

#Numerosità del dataset

numeroToTVini = arrayDimVini[0]
print(numeroToTVini)

numeroParamValut = arrayDimVini[1] # abbiamo 13 colonne, quindi con indice da 0 a 12

#Etichette

etichette = vini.columns
print(etichette)

indici = vini.index
print(indici)

#Valori
print(vini.dtypes)
vini["quality"] = vini["quality"].astype('float64')    #problema parzialmente risolto: per aver DataFrameVini
print(vini.dtypes)                                   #pieno dal numpy.ndarray values il tipo delle colonne
valori = vini.values                            #deve essere lo stesso per tutte, ma tutte erano float64 ed una int64
print(valori)                                #così ho convertito quella anche a float64,e, escludendo la colonna di tipo string 
                                                                           #↓
DataFrameVini = pd.DataFrame(valori) #si dovrebbe trovare il modo di creare 1 dataframe pieno, da degli array.values tipo numpy.ndarray creati da un altro dataframe
print("STAMPA DEL DATAFRAME")
print(DataFrameVini)

medie = DataFrameVini.mean(axis =0, numeric_only=True)
mode = DataFrameVini.mode(axis=0,numeric_only=True)
mediane = DataFrameVini.median(axis=0,numeric_only=True)
quartili = DataFrameVini.quantile([0.25,0.50,0.75],axis=0,numeric_only=True)
devstandards = DataFrameVini.std(axis=0,numeric_only=True)

print('medie', medie)
print('mode', mode)
print('mediane', mediane)
print('quartili', quartili)
print('devstandars', devstandards)