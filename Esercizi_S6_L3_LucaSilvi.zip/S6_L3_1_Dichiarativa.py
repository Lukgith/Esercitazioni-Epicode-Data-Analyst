import numpy as np 
import pandas as pd 

vini = pd.read_csv("wine.csv", usecols = range(0,11))

print(vini)
#media = np.mean() 
#mediana = np.median() 
#dev_std = np.std()

arrayDimVini = vini.shape

print(arrayDimVini) 

#Numerosità del dataset

numeroToTVini = arrayDimVini[0]
print(numeroToTVini)

numeroParamValut = arrayDimVini[1] # abbiamo 13 colonne, quindi con indice da 0 a 12

#Etichette

etichette = vini.columns
print(etichette)

indici = vini.index
print(indici)

#Valori

values = vini.values
print(values)

DataFrameVini = pd.DataFrame(values)

print(DataFrameVini)

                                                           #c'è da modificare per il numero di stampe

medieSuParam = [vini[v].mean() for v in vini.iloc[0:]] #non ha senso, giusto per capire le potenzialità della scrittura python dichiarativa
modeSuParam = [vini[v].mode() for v in vini.iloc[0:]]  #difatti stampa un numero di volte ogni funzionalita statistica pari a len(etichette)
medianeSuParam = [vini[v].median() for v in vini.iloc[0:]] #senza for il codice è uguale al file successivo
PrimQuartileSuParam = [vini[v].quantile(0.25) for v in vini.iloc[0:]]  #problema risolto, per risolverlo
TerQuartileSuParam = [vini[v].quantile(0.75) for v in vini.iloc[0:]]  # ho sostituito vini.iloc[0:] a vini
devstandsSuParam = [vini[v].std() for v in vini.iloc[0:]]             # per dire di fare for sul n° di indici di riga
bianchi = 0                                                          # ed ho sostituito vini[v].fx() a vini.fx()
rossi = 0                                                            #per chiedere l'op.statistica soltanto 
print('medie :',medieSuParam)                                        # sugli elementi della colonna v-esima
print('mode :',modeSuParam)
print('mediane :',medianeSuParam)
print('1i Quartili :',PrimQuartileSuParam)                           # difetto : codice più difficile da elaborare
print('3i Quartili :',TerQuartileSuParam)                            # pregio : visualizzazione compatta sul terminale
print('devstands :',devstandsSuParam) 