import numpy as np 
import pandas as pd 

vini = pd.read_csv("wine.csv")

print(vini)
#media = np.mean() 
#mediana = np.median() 
#dev_std = np.std()

arrayDimVini = vini.shape

print(arrayDimVini) 

#Numerosità del dataset

numeroToTVini = arrayDimVini[0]
print(numeroToTVini)

numeroParamValut = arrayDimVini[1] # abbiamo 13 colonne, quindi con indice da 0 a 12

#Etichette

etichette = vini.columns
print(etichette)

indici = vini.index
print(indici)

#Valori

values = vini.values
print(values)

DataFrameVini = pd.DataFrame(values)

print(DataFrameVini)

medieSuParam = []
modeSuParam = []
medianeSuParam = []
PrimQuartileSuParam = []
TerQuartileSuParam = []
devstandsSuParam = []
bianchi = 0
rossi = 0

for x in range(0,len(etichette),1):

    if x < len(etichette)-1:
        arrayColonna = DataFrameVini[x]
        print(arrayColonna) 
        media = np.mean(arrayColonna)
        moda = arrayColonna.mode()
        mediana = np.median(arrayColonna) 
        PrimQuartile = np.percentile(arrayColonna, 25)
        TerQuartile = np.percentile(arrayColonna, 75)
        devstand = np.std(arrayColonna)
        medieSuParam = np.append(medieSuParam,media)
        modeSuParam = np.append(modeSuParam,moda)
        medianeSuParam = np.append(medianeSuParam,mediana)
        PrimQuartileSuParam = np.append(PrimQuartileSuParam,PrimQuartile)
        TerQuartileSuParam = np.append(PrimQuartileSuParam,TerQuartile)
        devstandsSuParam = np.append(devstandsSuParam,devstand)

    elif x == 12 :
        for i in range(0,numeroToTVini,1) :
            if DataFrameVini[x][i] == "white" :
                bianchi += 1
            else :
                rossi += 1

print('Array con le medie :',medieSuParam)
print('Array con le mode :',modeSuParam)
print('Array con le mediane :',medianeSuParam)
print('Array con i 1i Quartili :',PrimQuartileSuParam)
print('Array con i 3i Quartili :',TerQuartileSuParam)
print('Array con le dev stands :',devstandsSuParam)
print('% bianchi = ', bianchi/numeroToTVini)
print('% rossi = ', rossi/numeroToTVini)
